/*******************************************************************************
* File Name: MTO_Pin1.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_MTO_Pin1_ALIASES_H) /* Pins MTO_Pin1_ALIASES_H */
#define CY_PINS_MTO_Pin1_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define MTO_Pin1_0			(MTO_Pin1__0__PC)
#define MTO_Pin1_0_PS		(MTO_Pin1__0__PS)
#define MTO_Pin1_0_PC		(MTO_Pin1__0__PC)
#define MTO_Pin1_0_DR		(MTO_Pin1__0__DR)
#define MTO_Pin1_0_SHIFT	(MTO_Pin1__0__SHIFT)
#define MTO_Pin1_0_INTR	((uint16)((uint16)0x0003u << (MTO_Pin1__0__SHIFT*2u)))

#define MTO_Pin1_INTR_ALL	 ((uint16)(MTO_Pin1_0_INTR))


#endif /* End Pins MTO_Pin1_ALIASES_H */


/* [] END OF FILE */
