/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"


int main(void) {
    CyGlobalIntEnable;
    
    CapSense_Start();
    CapSense_InitializeAllBaselines();
    CapSense_ScanEnabledWidgets();
  

    for(;;) {
        if(!CapSense_IsBusy()) {
            MTO_Pin_Write(!CapSense_CheckIsWidgetActive(CapSense_SENSOR_BUTTON0__BTN));
            
            CapSense_UpdateEnabledBaselines();
            CapSense_ScanEnabledWidgets();
            CySysPmSleep();
        }
    }
}

/* [] END OF FILE */
